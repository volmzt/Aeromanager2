package com.aerostudio.manager.core.storage

import android.content.ContentResolver
import android.content.Context
import android.os.Bundle
import android.provider.MediaStore
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

data class CategoryStat(val count: Int, val bytes: Long)

/**
 * Reads the system MediaStore index. Without "all files access" the index only
 * exposes media, and it can lag behind the real file system, so numbers are approximate.
 */
@Singleton
class MediaIndexRepository @Inject constructor(@ApplicationContext private val context: Context) {
    private val uri = MediaStore.Files.getContentUri("external")
    private val selection =
        "${MediaStore.Files.FileColumns.MIME_TYPE} IS NOT NULL AND ${MediaStore.Files.FileColumns.SIZE} > 0"

    suspend fun categoryStats(): Map<FileCategory, CategoryStat> {
        val counts = IntArray(FileCategory.entries.size)
        val bytes = LongArray(FileCategory.entries.size)
        try {
            val projection = arrayOf(
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.MIME_TYPE,
            )
            context.contentResolver.query(uri, projection, selection, null, null)?.use { c ->
                var n = 0
                while (c.moveToNext()) {
                    if (++n % 500 == 0) currentCoroutineContext().ensureActive()
                    val name = c.getString(1) ?: ""
                    val mime = c.getString(2) ?: ""
                    var cat = FileCategory.fromExtension(name.substringAfterLast('.', ""))
                    if (cat == FileCategory.OTHER) cat = FileCategory.fromMime(mime)
                    counts[cat.ordinal]++
                    bytes[cat.ordinal] += c.getLong(0)
                }
            }
        } catch (e: SecurityException) {
            // No access: report empty statistics.
        } catch (e: IllegalArgumentException) {
            // Provider rejected the query: report empty statistics.
        }
        return FileCategory.entries.filter { it != FileCategory.FOLDER }
            .associateWith { CategoryStat(counts[it.ordinal], bytes[it.ordinal]) }
    }

    suspend fun recentFiles(limit: Int = 8): List<FileItem> {
        val result = mutableListOf<FileItem>()
        try {
            val args = Bundle().apply {
                putString(ContentResolver.QUERY_ARG_SQL_SELECTION, selection)
                putStringArray(
                    ContentResolver.QUERY_ARG_SORT_COLUMNS,
                    arrayOf(MediaStore.Files.FileColumns.DATE_MODIFIED),
                )
                putInt(
                    ContentResolver.QUERY_ARG_SORT_DIRECTION,
                    ContentResolver.QUERY_SORT_DIRECTION_DESCENDING,
                )
                putInt(ContentResolver.QUERY_ARG_LIMIT, 80)
            }
            @Suppress("DEPRECATION")
            val dataColumn = MediaStore.Files.FileColumns.DATA
            context.contentResolver.query(uri, arrayOf(dataColumn), args, null)?.use { c ->
                while (c.moveToNext() && result.size < limit) {
                    currentCoroutineContext().ensureActive()
                    val path = c.getString(0) ?: continue
                    if (path.contains("/Android/")) continue
                    val f = File(path)
                    if (f.name.startsWith(".") || !f.isFile) continue
                    result.add(f.toFileItem())
                }
            }
        } catch (e: SecurityException) {
            // No access: no recent files.
        } catch (e: IllegalArgumentException) {
            // Provider rejected the query: no recent files.
        }
        return result
    }
}
