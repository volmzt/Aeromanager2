package com.aerostudio.manager

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aerostudio.manager.core.designsystem.AeroTheme
import com.aerostudio.manager.core.settings.SettingsViewModel
import com.aerostudio.manager.navigation.AeroApp
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val vm: SettingsViewModel = hiltViewModel()
            val settings by vm.settings.collectAsStateWithLifecycle()
            AeroTheme(settings = settings) { AeroApp() }
        }
    }
}
