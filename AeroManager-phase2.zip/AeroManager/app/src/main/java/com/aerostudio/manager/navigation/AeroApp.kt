package com.aerostudio.manager.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.aerostudio.manager.feature.dashboard.DashboardScreen
import com.aerostudio.manager.feature.explorer.ExplorerScreen
import com.aerostudio.manager.feature.placeholder.PlaceholderScreen
import com.aerostudio.manager.feature.settings.SettingsScreen

@Composable
fun AeroApp() {
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val current = entry?.destination?.route
    val goTo: (Destination) -> Unit = { d ->
        nav.navigate(d.route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }
    Scaffold(
        bottomBar = {
            NavigationBar {
                Destination.entries.forEach { d ->
                    NavigationBarItem(
                        selected = current == d.route,
                        onClick = { goTo(d) },
                        icon = { Icon(d.icon, contentDescription = null) },
                        label = { Text(stringResource(d.label)) },
                    )
                }
            }
        },
    ) { padding ->
        NavHost(nav, startDestination = Destination.Home.route, modifier = Modifier.padding(padding)) {
            composable(Destination.Home.route) { DashboardScreen(onOpenFiles = { goTo(Destination.Files) }) }
            composable(Destination.Files.route) { ExplorerScreen() }
            composable(Destination.Tools.route) { PlaceholderScreen(Destination.Tools.label) }
            composable(Destination.Favorites.route) { PlaceholderScreen(Destination.Favorites.label) }
            composable(Destination.Settings.route) { SettingsScreen() }
        }
    }
}
