package com.aerostudio.manager.core.settings

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsStore: DataStore<Preferences> by preferencesDataStore(name = "aero_settings")

private inline fun <reified T : Enum<T>> String?.toEnum(default: T): T =
    this?.let { runCatching { enumValueOf<T>(it) }.getOrNull() } ?: default

@Singleton
class SettingsRepository @Inject constructor(@ApplicationContext private val context: Context) {
    private val themeKey = stringPreferencesKey("theme_mode")
    private val accentKey = longPreferencesKey("accent")
    private val viewKey = stringPreferencesKey("view_mode")
    private val sortFieldKey = stringPreferencesKey("sort_field")
    private val sortAscKey = booleanPreferencesKey("sort_asc")
    private val hiddenKey = booleanPreferencesKey("show_hidden")

    val settings: Flow<AppSettings> = context.settingsStore.data.map { p ->
        AppSettings(
            themeMode = p[themeKey].toEnum(ThemeMode.SYSTEM),
            accent = p[accentKey] ?: AppSettings.DEFAULT_ACCENT,
            viewMode = p[viewKey].toEnum(ViewMode.LIST),
            sortField = p[sortFieldKey].toEnum(SortField.NAME),
            sortAscending = p[sortAscKey] ?: true,
            showHidden = p[hiddenKey] ?: false,
        )
    }

    suspend fun setThemeMode(mode: ThemeMode) { context.settingsStore.edit { it[themeKey] = mode.name } }
    suspend fun setAccent(argb: Long) { context.settingsStore.edit { it[accentKey] = argb } }
    suspend fun setViewMode(mode: ViewMode) { context.settingsStore.edit { it[viewKey] = mode.name } }
    suspend fun setSort(field: SortField, ascending: Boolean) {
        context.settingsStore.edit { it[sortFieldKey] = field.name; it[sortAscKey] = ascending }
    }
    suspend fun setShowHidden(show: Boolean) { context.settingsStore.edit { it[hiddenKey] = show } }
}
