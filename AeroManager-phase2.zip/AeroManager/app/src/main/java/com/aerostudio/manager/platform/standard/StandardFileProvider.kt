package com.aerostudio.manager.platform.standard

import com.aerostudio.manager.core.storage.FileAccessProvider
import com.aerostudio.manager.core.storage.FileError
import com.aerostudio.manager.core.storage.FileException
import com.aerostudio.manager.core.storage.FileItem
import com.aerostudio.manager.core.storage.toFileItem
import com.aerostudio.manager.core.storage.validateName
import java.io.File
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class StandardFileProvider @Inject constructor() : FileAccessProvider {
    override val id: String = "standard"

    override fun list(path: String, showHidden: Boolean): List<FileItem> = guard {
        val dir = File(path)
        if (!dir.exists() || !dir.isDirectory) throw FileException(FileError.NOT_FOUND)
        val children = dir.listFiles() ?: throw FileException(FileError.ACCESS_DENIED)
        val files = children.filter { showHidden || !it.name.startsWith(".") }
        val withCount = files.count { it.isDirectory } <= 300
        files.map { f ->
            val count = if (withCount && f.isDirectory) {
                f.list()?.count { n -> showHidden || !n.startsWith(".") }
            } else null
            f.toFileItem(count)
        }
    }

    override fun createFolder(parent: String, name: String): FileItem = guard {
        val target = prepare(parent, name)
        if (!target.mkdir()) throw FileException(FileError.ACCESS_DENIED)
        target.toFileItem(0)
    }

    override fun createFile(parent: String, name: String): FileItem = guard {
        val target = prepare(parent, name)
        try {
            if (!target.createNewFile()) throw FileException(FileError.ALREADY_EXISTS)
        } catch (e: IOException) {
            throw FileException(FileError.ACCESS_DENIED, cause = e)
        }
        target.toFileItem()
    }

    override fun rename(path: String, newName: String): FileItem = guard {
        val src = File(path)
        validateName(newName)?.let { throw FileException(it) }
        if (!src.exists()) throw FileException(FileError.NOT_FOUND)
        val target = File(src.parentFile, newName)
        val sameFile = target.exists() && target.canonicalPath == src.canonicalPath
        if (target.exists() && !sameFile) throw FileException(FileError.ALREADY_EXISTS)
        if (!src.renameTo(target)) throw FileException(FileError.ACCESS_DENIED)
        target.toFileItem()
    }

    private fun prepare(parent: String, name: String): File {
        validateName(name)?.let { throw FileException(it) }
        val dir = File(parent)
        if (!dir.isDirectory) throw FileException(FileError.NOT_FOUND)
        val target = File(dir, name)
        if (target.exists()) throw FileException(FileError.ALREADY_EXISTS)
        return target
    }

    private inline fun <T> guard(block: () -> T): T = try {
        block()
    } catch (e: FileException) {
        throw e
    } catch (e: SecurityException) {
        throw FileException(FileError.ACCESS_DENIED, cause = e)
    } catch (e: IOException) {
        throw FileException(FileError.IO, cause = e)
    }
}
