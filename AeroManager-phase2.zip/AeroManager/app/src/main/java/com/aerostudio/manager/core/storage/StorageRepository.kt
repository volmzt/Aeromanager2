package com.aerostudio.manager.core.storage

import android.content.Context
import android.os.Environment
import android.os.StatFs
import dagger.hilt.android.qualifiers.ApplicationContext
import java.io.File
import javax.inject.Inject
import javax.inject.Singleton

data class StorageVolume(
    val path: String,
    val isPrimary: Boolean,
    val name: String,
    val total: Long,
    val free: Long,
) {
    val used: Long get() = (total - free).coerceAtLeast(0)
    val usedFraction: Float get() = if (total > 0) used.toFloat() / total else 0f
}

@Singleton
class StorageRepository @Inject constructor(@ApplicationContext private val context: Context) {

    @Suppress("DEPRECATION")
    fun primaryRoot(): String = Environment.getExternalStorageDirectory().absolutePath

    /** Primary storage plus any removable volumes the system exposes as readable directories. */
    @Suppress("DEPRECATION")
    fun volumes(): List<StorageVolume> {
        val primary = Environment.getExternalStorageDirectory()
        val result = mutableListOf(volume(primary, true))
        context.getExternalFilesDirs(null).filterNotNull().forEach { dir ->
            val root = dir.absolutePath.substringBefore("/Android/data")
            if (root != dir.absolutePath && root != primary.absolutePath && result.none { it.path == root }) {
                val f = File(root)
                if (f.exists() && f.canRead()) result.add(volume(f, false))
            }
        }
        return result
    }

    private fun volume(dir: File, primary: Boolean): StorageVolume {
        var total = 0L
        var free = 0L
        try {
            val s = StatFs(dir.absolutePath)
            total = s.blockCountLong * s.blockSizeLong
            free = s.availableBytes
        } catch (e: Exception) {
            // Statistics unavailable: show zeros rather than fake numbers.
        }
        return StorageVolume(dir.absolutePath, primary, dir.name, total, free)
    }
}
