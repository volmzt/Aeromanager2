package com.aerostudio.manager.core.designsystem

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AudioFile
import androidx.compose.material.icons.outlined.Android
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.InsertDriveFile
import androidx.compose.material.icons.outlined.VideoFile
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import com.aerostudio.manager.R
import com.aerostudio.manager.core.storage.FileCategory

fun categoryColor(cat: FileCategory): Color = when (cat) {
    FileCategory.FOLDER -> Color(0xFFF9A825)
    FileCategory.IMAGE -> Color(0xFF43A047)
    FileCategory.VIDEO -> Color(0xFF8E24AA)
    FileCategory.AUDIO -> Color(0xFFE53935)
    FileCategory.DOCUMENT -> Color(0xFF1E88E5)
    FileCategory.APK -> Color(0xFF00897B)
    FileCategory.ARCHIVE -> Color(0xFFEF6C00)
    FileCategory.OTHER -> Color(0xFF78909C)
}

fun categoryIcon(cat: FileCategory): ImageVector = when (cat) {
    FileCategory.FOLDER -> Icons.Outlined.Folder
    FileCategory.IMAGE -> Icons.Outlined.Image
    FileCategory.VIDEO -> Icons.Outlined.VideoFile
    FileCategory.AUDIO -> Icons.Outlined.AudioFile
    FileCategory.DOCUMENT -> Icons.Outlined.Description
    FileCategory.APK -> Icons.Outlined.Android
    FileCategory.ARCHIVE -> Icons.Outlined.FolderZip
    FileCategory.OTHER -> Icons.Outlined.InsertDriveFile
}

@StringRes
fun categoryLabel(cat: FileCategory): Int = when (cat) {
    FileCategory.FOLDER -> R.string.type_folder
    FileCategory.IMAGE -> R.string.cat_images
    FileCategory.VIDEO -> R.string.cat_videos
    FileCategory.AUDIO -> R.string.cat_audio
    FileCategory.DOCUMENT -> R.string.cat_documents
    FileCategory.APK -> R.string.cat_apk
    FileCategory.ARCHIVE -> R.string.cat_archives
    FileCategory.OTHER -> R.string.cat_other
}
