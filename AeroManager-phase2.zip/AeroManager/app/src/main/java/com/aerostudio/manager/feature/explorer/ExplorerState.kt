package com.aerostudio.manager.feature.explorer

import androidx.annotation.StringRes
import com.aerostudio.manager.R
import com.aerostudio.manager.core.settings.SortField
import com.aerostudio.manager.core.settings.ViewMode
import com.aerostudio.manager.core.storage.FileError
import com.aerostudio.manager.core.storage.FileItem
import com.aerostudio.manager.core.storage.OperationProgress
import com.aerostudio.manager.core.storage.OperationResult
import com.aerostudio.manager.core.storage.StorageVolume

data class Clipboard(val paths: List<String>, val move: Boolean)

data class ConflictRequest(val clipboard: Clipboard, val destination: String, val names: List<String>)

data class UiMessage(@StringRes val res: Int, val arg: String? = null)

data class ExplorerState(
    val root: String = "",
    val path: String = "",
    val items: List<FileItem> = emptyList(),
    val loading: Boolean = false,
    val error: FileError? = null,
    val viewMode: ViewMode = ViewMode.LIST,
    val sortField: SortField = SortField.NAME,
    val sortAscending: Boolean = true,
    val showHidden: Boolean = false,
    val selection: Set<String> = emptySet(),
    val clipboard: Clipboard? = null,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val operation: OperationProgress? = null,
    val conflict: ConflictRequest? = null,
    val pendingDelete: List<String>? = null,
    val report: OperationResult? = null,
    val volumes: List<StorageVolume> = emptyList(),
) {
    val selecting: Boolean get() = selection.isNotEmpty()
    val canGoUp: Boolean get() = path.isNotEmpty() && path != root
}

@StringRes
fun FileError.messageRes(): Int = when (this) {
    FileError.ACCESS_DENIED -> R.string.err_access_denied
    FileError.NOT_FOUND -> R.string.err_not_found
    FileError.ALREADY_EXISTS -> R.string.err_exists
    FileError.INVALID_NAME -> R.string.err_invalid_name
    FileError.NO_SPACE -> R.string.err_no_space
    FileError.INSIDE_ITSELF -> R.string.err_inside_itself
    FileError.VERIFY_FAILED -> R.string.err_verify
    FileError.TYPE_MISMATCH -> R.string.err_type_mismatch
    FileError.IO -> R.string.err_io
}
