package com.aerostudio.manager.core.storage

enum class FileCategory {
    FOLDER, IMAGE, VIDEO, AUDIO, DOCUMENT, APK, ARCHIVE, OTHER;

    companion object {
        fun fromExtension(ext: String): FileCategory = when (ext.lowercase()) {
            "jpg", "jpeg", "png", "gif", "webp", "bmp", "heic", "heif", "svg" -> IMAGE
            "mp4", "mkv", "avi", "mov", "webm", "3gp", "m4v", "flv", "wmv" -> VIDEO
            "mp3", "wav", "flac", "aac", "m4a", "ogg", "opus", "wma", "amr" -> AUDIO
            "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "rtf", "odt", "ods", "odp",
            "csv", "md", "json", "xml", "html", "epub" -> DOCUMENT
            "apk", "apks", "xapk", "apkm" -> APK
            "zip", "rar", "7z", "tar", "gz", "bz2", "xz", "tgz" -> ARCHIVE
            else -> OTHER
        }

        fun fromMime(mime: String): FileCategory = when {
            mime.startsWith("image/") -> IMAGE
            mime.startsWith("video/") -> VIDEO
            mime.startsWith("audio/") -> AUDIO
            mime.startsWith("text/") -> DOCUMENT
            else -> OTHER
        }
    }
}
