package com.aerostudio.manager.feature.explorer

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.aerostudio.manager.R
import com.aerostudio.manager.core.common.formatDate
import com.aerostudio.manager.core.common.formatSize
import com.aerostudio.manager.core.common.itemsText
import com.aerostudio.manager.core.designsystem.categoryColor
import com.aerostudio.manager.core.designsystem.categoryIcon
import com.aerostudio.manager.core.settings.ViewMode
import com.aerostudio.manager.core.storage.FileCategory
import com.aerostudio.manager.core.storage.FileItem

@Composable
fun FileIcon(category: FileCategory, selected: Boolean, size: Dp = 40.dp) {
    val color = categoryColor(category)
    val bg = if (selected) MaterialTheme.colorScheme.primary else color.copy(alpha = 0.16f)
    Box(
        Modifier.size(size).clip(RoundedCornerShape(10.dp)).background(bg),
        contentAlignment = Alignment.Center,
    ) {
        if (selected) {
            Icon(Icons.Outlined.Check, null, tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(size * 0.55f))
        } else {
            Icon(categoryIcon(category), null, tint = color, modifier = Modifier.size(size * 0.55f))
        }
    }
}

@Composable
private fun typeLabel(item: FileItem): String =
    if (item.isDirectory) stringResource(R.string.type_folder)
    else item.extension.uppercase().ifEmpty { stringResource(R.string.type_file) }

@Composable
private fun sizeText(item: FileItem): String {
    val context = LocalContext.current
    return if (item.isDirectory) {
        item.childCount?.let { itemsText(it) } ?: ""
    } else formatSize(context, item.size)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FileEntry(
    item: FileItem,
    mode: ViewMode,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    val bg = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
    val base = Modifier
        .clip(RoundedCornerShape(12.dp))
        .background(bg)
        .combinedClickable(onClick = onClick, onLongClick = onLongClick)

    when (mode) {
        ViewMode.GRID -> Column(
            base.fillMaxWidth().padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            FileIcon(item.category, selected, 56.dp)
            Spacer(Modifier.size(6.dp))
            Text(
                item.name,
                style = MaterialTheme.typography.bodySmall,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center,
            )
        }

        ViewMode.COMPACT -> Row(
            base.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FileIcon(item.category, selected, 28.dp)
            Spacer(Modifier.width(12.dp))
            Text(
                item.name,
                style = MaterialTheme.typography.bodyMedium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Spacer(Modifier.width(8.dp))
            Text(
                sizeText(item),
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }

        ViewMode.LIST, ViewMode.DETAILED -> Row(
            base.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            FileIcon(item.category, selected, 40.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(
                    item.name,
                    style = MaterialTheme.typography.bodyLarge,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                val size = sizeText(item)
                val date = formatDate(item.modified)
                Text(
                    if (size.isEmpty()) date else "$size · $date",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                )
                if (mode == ViewMode.DETAILED) {
                    Text(
                        typeLabel(item),
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}
