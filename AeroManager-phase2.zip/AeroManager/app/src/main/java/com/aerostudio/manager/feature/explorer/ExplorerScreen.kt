package com.aerostudio.manager.feature.explorer

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.MoreVert
import androidx.compose.material.icons.outlined.Refresh
import androidx.compose.material.icons.outlined.SelectAll
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aerostudio.manager.R
import com.aerostudio.manager.core.permissions.PermissionCard
import com.aerostudio.manager.core.permissions.rememberStorageAccess
import com.aerostudio.manager.core.settings.SortField
import com.aerostudio.manager.core.settings.ViewMode
import com.aerostudio.manager.core.storage.FileItem
import com.aerostudio.manager.core.storage.FileOpener

sealed interface ExplorerDialog {
    data object NewFolder : ExplorerDialog
    data object NewFile : ExplorerDialog
    data class Rename(val items: List<FileItem>) : ExplorerDialog
    data class Info(val item: FileItem) : ExplorerDialog
}

private fun sortLabel(f: SortField): Int = when (f) {
    SortField.NAME -> R.string.sort_name
    SortField.SIZE -> R.string.sort_size
    SortField.DATE -> R.string.sort_date
    SortField.TYPE -> R.string.sort_type
}

private fun viewLabel(m: ViewMode): Int = when (m) {
    ViewMode.LIST -> R.string.view_list
    ViewMode.GRID -> R.string.view_grid
    ViewMode.COMPACT -> R.string.view_compact
    ViewMode.DETAILED -> R.string.view_detailed
}

private fun copyToClipboard(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("path", text))
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ExplorerScreen(vm: ExplorerViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val access = rememberStorageAccess()
    val snackbar = remember { SnackbarHostState() }
    var dialog by remember { mutableStateOf<ExplorerDialog?>(null) }
    var menuOpen by remember { mutableStateOf(false) }
    var fabMenu by remember { mutableStateOf(false) }
    var selMenu by remember { mutableStateOf(false) }

    LaunchedEffect(access.granted) { if (access.granted) vm.start() }
    LaunchedEffect(Unit) {
        vm.events.collect { m ->
            val text = if (m.arg != null) context.getString(m.res, m.arg) else context.getString(m.res)
            snackbar.showSnackbar(text)
        }
    }
    BackHandler(enabled = access.granted && (state.selecting || state.canGoBack || state.canGoUp)) {
        if (state.selecting) vm.clearSelection() else vm.goBack()
    }

    if (!access.granted) {
        Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            PermissionCard(onGrant = access.request)
        }
        return
    }

    val selectedItems = remember(state.items, state.selection) {
        state.items.filter { it.path in state.selection }
    }
    val rootLabel = state.volumes.firstOrNull { it.path == state.root }.let { v ->
        if (v == null || v.isPrimary) stringResource(R.string.dash_internal) else v.name
    }

    val onItemClick: (FileItem) -> Unit = { item ->
        when {
            state.selecting -> vm.toggleSelection(item.path)
            item.isDirectory -> vm.open(item)
            !FileOpener.open(context, item.path) -> vm.notify(R.string.msg_no_app)
            else -> {}
        }
    }
    val onItemLongClick: (FileItem) -> Unit = { item -> vm.toggleSelection(item.path) }

    Column(Modifier.fillMaxSize()) {
        // ---------- header ----------
        if (state.selecting) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::clearSelection) { Icon(Icons.Outlined.Close, stringResource(R.string.action_close)) }
                Text(
                    stringResource(R.string.selected_count, state.selection.size),
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.weight(1f),
                )
                IconButton(onClick = vm::selectAll) { Icon(Icons.Outlined.SelectAll, stringResource(R.string.action_select_all)) }
                Box {
                    IconButton(onClick = { selMenu = true }) { Icon(Icons.Outlined.MoreVert, stringResource(R.string.action_more)) }
                    DropdownMenu(expanded = selMenu, onDismissRequest = { selMenu = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_invert)) },
                            onClick = { selMenu = false; vm.invertSelection() },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_rename)) },
                            onClick = { selMenu = false; dialog = ExplorerDialog.Rename(selectedItems) },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_copy_path)) },
                            onClick = {
                                selMenu = false
                                copyToClipboard(context, selectedItems.joinToString("\n") { it.path })
                                vm.notify(R.string.msg_path_copied)
                            },
                        )
                        if (selectedItems.size == 1) {
                            DropdownMenuItem(
                                text = { Text(stringResource(R.string.action_info)) },
                                onClick = { selMenu = false; dialog = ExplorerDialog.Info(selectedItems[0]) },
                            )
                        }
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = vm::goBack, enabled = state.canGoBack || state.canGoUp) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, stringResource(R.string.action_back))
                }
                IconButton(onClick = vm::goForward, enabled = state.canGoForward) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, stringResource(R.string.action_forward))
                }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = vm::refresh) { Icon(Icons.Outlined.Refresh, stringResource(R.string.action_refresh)) }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Outlined.MoreVert, stringResource(R.string.action_more)) }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        MenuLabel(stringResource(R.string.menu_sort_by))
                        SortField.entries.forEach { f ->
                            DropdownMenuItem(
                                text = { Text(stringResource(sortLabel(f))) },
                                leadingIcon = { RadioButton(selected = state.sortField == f, onClick = null) },
                                onClick = { vm.setSort(f, state.sortAscending) },
                            )
                        }
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.sort_ascending)) },
                            leadingIcon = { Checkbox(checked = state.sortAscending, onCheckedChange = null) },
                            onClick = { vm.setSort(state.sortField, !state.sortAscending) },
                        )
                        HorizontalDivider()
                        MenuLabel(stringResource(R.string.menu_view))
                        ViewMode.entries.forEach { m ->
                            DropdownMenuItem(
                                text = { Text(stringResource(viewLabel(m))) },
                                leadingIcon = { RadioButton(selected = state.viewMode == m, onClick = null) },
                                onClick = { vm.setViewMode(m) },
                            )
                        }
                        HorizontalDivider()
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.menu_show_hidden)) },
                            leadingIcon = { Checkbox(checked = state.showHidden, onCheckedChange = null) },
                            onClick = { vm.setShowHidden(!state.showHidden) },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_copy_path)) },
                            onClick = {
                                menuOpen = false
                                copyToClipboard(context, state.path)
                                vm.notify(R.string.msg_path_copied)
                            },
                        )
                        if (state.volumes.size > 1) {
                            HorizontalDivider()
                            MenuLabel(stringResource(R.string.menu_storage))
                            state.volumes.forEach { v ->
                                DropdownMenuItem(
                                    text = {
                                        Text(if (v.isPrimary) stringResource(R.string.dash_internal) else v.name)
                                    },
                                    onClick = { menuOpen = false; vm.navigateTo(v.path) },
                                )
                            }
                        }
                    }
                }
            }
            Breadcrumb(state.root, state.path, rootLabel, vm::navigateTo)
        }

        // ---------- content ----------
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                state.loading && state.items.isEmpty() ->
                    CircularProgressIndicator(Modifier.align(Alignment.Center))

                state.error != null -> Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text(stringResource(R.string.explorer_error_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(state.error!!.messageRes()), style = MaterialTheme.typography.bodyMedium)
                }

                state.items.isEmpty() -> Text(
                    stringResource(R.string.explorer_empty),
                    modifier = Modifier.align(Alignment.Center),
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )

                else -> Crossfade(targetState = state.viewMode, label = "viewMode") { mode ->
                    if (mode == ViewMode.GRID) {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(96.dp),
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 8.dp, top = 4.dp, end = 8.dp, bottom = 88.dp),
                        ) {
                            items(state.items, key = { it.path }) { item ->
                                FileEntry(
                                    item, mode, item.path in state.selection,
                                    onClick = { onItemClick(item) },
                                    onLongClick = { onItemLongClick(item) },
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(start = 8.dp, top = 4.dp, end = 8.dp, bottom = 88.dp),
                        ) {
                            items(state.items, key = { it.path }) { item ->
                                FileEntry(
                                    item, mode, item.path in state.selection,
                                    onClick = { onItemClick(item) },
                                    onLongClick = { onItemLongClick(item) },
                                )
                            }
                        }
                    }
                }
            }

            if (!state.selecting) {
                Box(Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
                    FloatingActionButton(onClick = { fabMenu = true }) {
                        Icon(Icons.Outlined.Add, stringResource(R.string.action_create))
                    }
                    DropdownMenu(expanded = fabMenu, onDismissRequest = { fabMenu = false }) {
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_new_folder)) },
                            onClick = { fabMenu = false; dialog = ExplorerDialog.NewFolder },
                        )
                        DropdownMenuItem(
                            text = { Text(stringResource(R.string.action_new_file)) },
                            onClick = { fabMenu = false; dialog = ExplorerDialog.NewFile },
                        )
                    }
                }
            }
            SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter))
        }

        // ---------- bottom bars ----------
        if (state.selecting) {
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    BarAction(Icons.Outlined.ContentCopy, stringResource(R.string.action_copy)) { vm.copySelection(false) }
                    BarAction(Icons.Outlined.ContentCut, stringResource(R.string.action_cut)) { vm.copySelection(true) }
                    BarAction(Icons.Outlined.Delete, stringResource(R.string.action_delete)) { vm.requestDelete() }
                    BarAction(Icons.Outlined.Share, stringResource(R.string.action_share)) {
                        if (!FileOpener.share(context, selectedItems.map { it.path })) {
                            vm.notify(R.string.msg_share_files_only)
                        }
                    }
                }
            }
        } else state.clipboard?.let { clip ->
            Surface(tonalElevation = 3.dp) {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        stringResource(
                            if (clip.move) R.string.clipboard_move else R.string.clipboard_copy,
                            clip.paths.size,
                        ),
                        modifier = Modifier.weight(1f),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    TextButton(onClick = vm::cancelClipboard) { Text(stringResource(R.string.action_cancel)) }
                    Button(onClick = vm::paste) { Text(stringResource(R.string.action_paste)) }
                }
            }
        }
    }

    // ---------- dialogs ----------
    when (val d = dialog) {
        ExplorerDialog.NewFolder -> NameDialog(
            stringResource(R.string.dlg_new_folder_title), "", stringResource(R.string.field_name),
            onConfirm = { vm.create(it, true); dialog = null },
            onDismiss = { dialog = null },
        )
        ExplorerDialog.NewFile -> NameDialog(
            stringResource(R.string.dlg_new_file_title), "", stringResource(R.string.field_name),
            onConfirm = { vm.create(it, false); dialog = null },
            onDismiss = { dialog = null },
        )
        is ExplorerDialog.Rename -> if (d.items.size == 1) {
            NameDialog(
                stringResource(R.string.dlg_rename_title), d.items[0].name, stringResource(R.string.field_name),
                onConfirm = { vm.rename(d.items[0], it); dialog = null },
                onDismiss = { dialog = null },
            )
        } else {
            NameDialog(
                stringResource(R.string.dlg_batch_rename_title, d.items.size), "",
                stringResource(R.string.dlg_batch_rename_hint),
                onConfirm = { vm.batchRename(d.items, it); dialog = null },
                onDismiss = { dialog = null },
            )
        }
        is ExplorerDialog.Info -> InfoDialog(d.item) { dialog = null }
        null -> {}
    }

    state.pendingDelete?.let { DeleteDialog(it.size, onConfirm = vm::confirmDelete, onDismiss = vm::cancelDelete) }
    state.conflict?.let { ConflictDialog(it, onChoose = vm::resolveConflict) }
    state.operation?.let { ProgressDialog(it, onCancel = vm::cancelOperation) }
    state.report?.let { ReportDialog(it, onDismiss = vm::dismissReport) }
}

@Composable
private fun MenuLabel(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
    )
}

@Composable
private fun BarAction(icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, Modifier.size(22.dp))
        Text(label, fontSize = 11.sp)
    }
}

@Composable
private fun Breadcrumb(root: String, path: String, rootLabel: String, onNavigate: (String) -> Unit) {
    val rel = path.removePrefix(root).trim('/')
    val parts = if (rel.isEmpty()) emptyList() else rel.split('/')
    val base = root.trimEnd('/')
    val listState = rememberLazyListState()
    LaunchedEffect(path) { listState.scrollToItem(parts.size) }
    LazyRow(state = listState, modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp)) {
        item { Crumb(rootLabel, parts.isEmpty()) { onNavigate(root) } }
        itemsIndexed(parts) { i, p ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("›", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Crumb(p, i == parts.lastIndex) {
                    onNavigate(base + "/" + parts.take(i + 1).joinToString("/"))
                }
            }
        }
    }
}

@Composable
private fun Crumb(text: String, last: Boolean, onClick: () -> Unit) {
    Text(
        text,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
        color = if (last) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 6.dp),
    )
}
