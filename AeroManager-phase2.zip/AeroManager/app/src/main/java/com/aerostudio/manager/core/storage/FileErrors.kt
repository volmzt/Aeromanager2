package com.aerostudio.manager.core.storage

enum class FileError {
    ACCESS_DENIED, NOT_FOUND, ALREADY_EXISTS, INVALID_NAME, NO_SPACE,
    INSIDE_ITSELF, VERIFY_FAILED, TYPE_MISMATCH, IO,
}

class FileException(val error: FileError, message: String? = null, cause: Throwable? = null) :
    Exception(message, cause)

/** Returns an error if [name] cannot be used as a single file or folder name. */
fun validateName(name: String): FileError? = when {
    name.isBlank() -> FileError.INVALID_NAME
    name == "." || name == ".." -> FileError.INVALID_NAME
    name.contains('/') || name.contains('\u0000') -> FileError.INVALID_NAME
    name.length > 255 -> FileError.INVALID_NAME
    else -> null
}
