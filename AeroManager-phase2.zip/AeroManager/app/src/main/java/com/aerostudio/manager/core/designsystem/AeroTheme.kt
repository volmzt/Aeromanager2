package com.aerostudio.manager.core.designsystem

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.dp
import com.aerostudio.manager.core.settings.AppSettings
import com.aerostudio.manager.core.settings.ThemeMode

/** Black or white, whichever is readable on top of [color]. */
fun readableOn(color: Color): Color = if (color.luminance() > 0.5f) Color.Black else Color.White

/** Ready-made accent presets (ARGB). */
val AccentPresets: List<Long> = listOf(
    0xFF1E88E5, 0xFF00ACC1, 0xFF43A047, 0xFFF9A825, 0xFFE53935, 0xFF8E24AA,
)

fun aeroColorScheme(accentArgb: Long, dark: Boolean): ColorScheme {
    val accent = Color(accentArgb.toInt())
    return if (dark) {
        val primary = lerp(accent, Color.White, 0.25f)
        darkColorScheme(
            primary = primary,
            onPrimary = readableOn(primary),
            primaryContainer = lerp(accent, Color.Black, 0.55f),
            onPrimaryContainer = Color.White,
            background = Color(0xFF0E1116),
            surface = Color(0xFF0E1116),
            surfaceVariant = Color(0xFF1A1F27),
        )
    } else {
        lightColorScheme(
            primary = accent,
            onPrimary = readableOn(accent),
            primaryContainer = lerp(accent, Color.White, 0.82f),
            onPrimaryContainer = Color.Black,
            background = Color(0xFFF7F9FC),
            surface = Color(0xFFF7F9FC),
            surfaceVariant = Color(0xFFE9EDF3),
        )
    }
}

private val AeroShapes = Shapes(
    small = RoundedCornerShape(8.dp),
    medium = RoundedCornerShape(12.dp),
    large = RoundedCornerShape(16.dp),
)

@Composable
fun AeroTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val dark = when (settings.themeMode) {
        ThemeMode.SYSTEM -> isSystemInDarkTheme()
        ThemeMode.LIGHT -> false
        ThemeMode.DARK -> true
    }
    MaterialTheme(
        colorScheme = aeroColorScheme(settings.accent, dark),
        shapes = AeroShapes,
        content = content,
    )
}
