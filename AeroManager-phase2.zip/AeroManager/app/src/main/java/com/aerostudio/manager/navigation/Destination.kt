package com.aerostudio.manager.navigation

import androidx.annotation.StringRes
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.Handyman
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarOutline
import androidx.compose.ui.graphics.vector.ImageVector
import com.aerostudio.manager.R

enum class Destination(val route: String, @StringRes val label: Int, val icon: ImageVector) {
    Home("home", R.string.nav_home, Icons.Outlined.Home),
    Files("files", R.string.nav_files, Icons.Outlined.Folder),
    Tools("tools", R.string.nav_tools, Icons.Outlined.Handyman),
    Favorites("favorites", R.string.nav_favorites, Icons.Outlined.StarOutline),
    Settings("settings", R.string.nav_settings, Icons.Outlined.Settings),
}
