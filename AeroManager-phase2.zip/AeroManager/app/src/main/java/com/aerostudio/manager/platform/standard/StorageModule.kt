package com.aerostudio.manager.platform.standard

import com.aerostudio.manager.core.storage.FileAccessProvider
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

@Module
@InstallIn(SingletonComponent::class)
abstract class StorageModule {
    @Binds
    abstract fun bindFileAccessProvider(impl: StandardFileProvider): FileAccessProvider
}
