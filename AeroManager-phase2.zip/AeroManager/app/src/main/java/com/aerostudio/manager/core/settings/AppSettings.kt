package com.aerostudio.manager.core.settings

enum class ThemeMode { SYSTEM, LIGHT, DARK }
enum class ViewMode { LIST, GRID, COMPACT, DETAILED }
enum class SortField { NAME, SIZE, DATE, TYPE }

data class AppSettings(
    val themeMode: ThemeMode = ThemeMode.SYSTEM,
    /** ARGB accent color. */
    val accent: Long = DEFAULT_ACCENT,
    val viewMode: ViewMode = ViewMode.LIST,
    val sortField: SortField = SortField.NAME,
    val sortAscending: Boolean = true,
    val showHidden: Boolean = false,
) {
    companion object { const val DEFAULT_ACCENT: Long = 0xFF1E88E5 }
}
