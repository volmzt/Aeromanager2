package com.aerostudio.manager.feature.explorer

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.aerostudio.manager.R
import com.aerostudio.manager.core.common.formatDate
import com.aerostudio.manager.core.common.formatDuration
import com.aerostudio.manager.core.common.formatSize
import com.aerostudio.manager.core.common.itemsText
import com.aerostudio.manager.core.storage.ConflictPolicy
import com.aerostudio.manager.core.storage.FileItem
import com.aerostudio.manager.core.storage.OperationProgress
import com.aerostudio.manager.core.storage.OperationResult
import com.aerostudio.manager.core.storage.OperationType
import com.aerostudio.manager.core.storage.isSymlink
import java.io.File
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

@Composable
fun NameDialog(
    title: String,
    initial: String,
    label: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(label) },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text) }, enabled = text.isNotBlank()) {
                Text(stringResource(R.string.action_ok))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

@Composable
fun DeleteDialog(count: Int, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.dlg_delete_title)) },
        text = { Text(stringResource(R.string.dlg_delete_body, itemsText(count))) },
        confirmButton = {
            TextButton(onClick = onConfirm) {
                Text(stringResource(R.string.action_delete), color = MaterialTheme.colorScheme.error)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_cancel)) } },
    )
}

@Composable
fun ConflictDialog(request: ConflictRequest, onChoose: (ConflictPolicy?) -> Unit) {
    AlertDialog(
        onDismissRequest = { onChoose(null) },
        title = { Text(stringResource(R.string.dlg_conflict_title)) },
        text = {
            Column {
                Text(stringResource(R.string.dlg_conflict_body, request.names.size))
                Spacer(Modifier.height(8.dp))
                Text(
                    request.names.take(5).joinToString("\n") +
                        if (request.names.size > 5) "\n…" else "",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        },
        confirmButton = {
            Row {
                TextButton(onClick = { onChoose(ConflictPolicy.SKIP) }) { Text(stringResource(R.string.action_skip)) }
                TextButton(onClick = { onChoose(ConflictPolicy.KEEP_BOTH) }) { Text(stringResource(R.string.action_keep_both)) }
                TextButton(onClick = { onChoose(ConflictPolicy.REPLACE) }) { Text(stringResource(R.string.action_replace)) }
            }
        },
        dismissButton = { TextButton(onClick = { onChoose(null) }) { Text(stringResource(R.string.action_cancel)) } },
    )
}

@Composable
fun ProgressDialog(progress: OperationProgress, onCancel: () -> Unit) {
    val context = LocalContext.current
    val title = when (progress.type) {
        OperationType.COPY -> R.string.op_copying
        OperationType.MOVE -> R.string.op_moving
        OperationType.DELETE -> R.string.op_deleting
    }
    val fraction = when {
        progress.totalBytes > 0 -> progress.doneBytes.toFloat() / progress.totalBytes
        progress.totalFiles > 0 -> progress.doneFiles.toFloat() / progress.totalFiles
        else -> -1f
    }
    AlertDialog(
        onDismissRequest = {},
        title = { Text(stringResource(title)) },
        text = {
            Column {
                Text(progress.currentName, maxLines = 1, style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(12.dp))
                if (fraction < 0f) LinearProgressIndicator(Modifier.fillMaxWidth())
                else LinearProgressIndicator(progress = { fraction.coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text(
                    stringResource(R.string.op_files_progress, progress.doneFiles, progress.totalFiles),
                    style = MaterialTheme.typography.bodySmall,
                )
                if (progress.type != OperationType.DELETE && progress.totalBytes > 0) {
                    Text(
                        "${formatSize(context, progress.doneBytes)} / ${formatSize(context, progress.totalBytes)}",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (progress.bytesPerSecond > 0) {
                        Text(
                            stringResource(R.string.op_speed, formatSize(context, progress.bytesPerSecond)),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                    progress.etaSeconds?.let {
                        Text(
                            stringResource(R.string.op_eta, formatDuration(it)),
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onCancel) { Text(stringResource(R.string.action_cancel)) }
        },
    )
}

@Composable
fun ReportDialog(result: OperationResult, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.op_report_title)) },
        text = {
            Column {
                Text(stringResource(R.string.op_summary, result.done, result.skipped, result.failures.size))
                Spacer(Modifier.height(8.dp))
                Column(Modifier.heightIn(max = 240.dp).verticalScroll(rememberScrollState())) {
                    result.failures.forEach { f ->
                        Text(
                            "${File(f.path).name} — ${stringResource(f.error.messageRes())}",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(vertical = 2.dp),
                        )
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_ok)) } },
    )
}

private fun CoroutineScope.folderSize(root: File): Long {
    var total = 0L
    for (f in root.walkTopDown().onEnter { !it.isSymlink() }) {
        ensureActive()
        if (f.isFile) total += f.length()
    }
    return total
}

@Composable
fun InfoDialog(item: FileItem, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val size by produceState<Long?>(initialValue = if (item.isDirectory) null else item.size, item.path) {
        if (item.isDirectory) value = withContext(Dispatchers.IO) { folderSize(File(item.path)) }
    }
    val file = File(item.path)
    val access = when {
        file.canRead() && file.canWrite() -> R.string.access_rw
        file.canRead() -> R.string.access_r
        else -> R.string.access_none
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(stringResource(R.string.info_title)) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                InfoRow(stringResource(R.string.info_name), item.name)
                InfoRow(stringResource(R.string.info_path), item.path)
                InfoRow(
                    stringResource(R.string.info_size),
                    size?.let { formatSize(context, it) } ?: stringResource(R.string.info_calculating),
                )
                if (item.isDirectory && item.childCount != null) {
                    InfoRow(stringResource(R.string.info_contents), itemsText(item.childCount))
                }
                InfoRow(stringResource(R.string.info_modified), formatDate(item.modified))
                InfoRow(
                    stringResource(R.string.info_type),
                    if (item.isDirectory) stringResource(R.string.type_folder)
                    else item.extension.uppercase().ifEmpty { stringResource(R.string.type_file) },
                )
                InfoRow(stringResource(R.string.info_access), stringResource(access))
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.action_close)) } },
    )
}

@Composable
private fun InfoRow(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
