package com.aerostudio.manager.core.storage

import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import javax.inject.Inject
import javax.inject.Singleton
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive

enum class OperationType { COPY, MOVE, DELETE }
enum class ConflictPolicy { SKIP, REPLACE, KEEP_BOTH }

data class OperationProgress(
    val type: OperationType,
    val currentName: String = "",
    val doneFiles: Int = 0,
    val totalFiles: Int = 0,
    val doneBytes: Long = 0,
    val totalBytes: Long = 0,
    val bytesPerSecond: Long = 0,
    val etaSeconds: Long? = null,
)

data class OperationFailure(val path: String, val error: FileError)

data class OperationResult(
    val done: Int,
    val skipped: Int,
    val failures: List<OperationFailure>,
    val cancelled: Boolean,
) {
    val hasIssues: Boolean get() = failures.isNotEmpty() || skipped > 0
}

private class StopRun : Exception()

/**
 * Copy / move / delete with progress, cancellation and explicit conflict handling.
 * Files are copied to a hidden temp file, verified by size, and only then renamed
 * into place, so a failed or cancelled copy never leaves a half-written target.
 * Call from a background dispatcher; cancel by cancelling the calling coroutine.
 */
@Singleton
class FileOperationEngine @Inject constructor() {

    /** Names of sources that already exist in [destDir] (same-folder copies are handled automatically). */
    fun findConflicts(sources: List<String>, destDir: String): List<String> {
        val destCanon = canon(File(destDir))
        return sources.map { File(it) }
            .filter { it.parentFile?.let { p -> canon(p) } != destCanon }
            .filter { File(destDir, it.name).exists() }
            .map { it.name }
    }

    suspend fun transfer(
        type: OperationType,
        sources: List<String>,
        destDir: String,
        policy: ConflictPolicy,
        onProgress: (OperationProgress) -> Unit,
    ): OperationResult = Run(type, onProgress).transfer(sources, destDir, policy)

    suspend fun delete(paths: List<String>, onProgress: (OperationProgress) -> Unit): OperationResult =
        Run(OperationType.DELETE, onProgress).delete(paths)
}

private fun canon(f: File): String = try { f.canonicalPath } catch (e: IOException) { f.absolutePath }

private class Run(
    private val type: OperationType,
    private val onProgress: (OperationProgress) -> Unit,
) {
    private var totalFiles = 0
    private var totalBytes = 0L
    private var doneFiles = 0
    private var doneBytes = 0L
    private var done = 0
    private var skipped = 0
    private val failures = mutableListOf<OperationFailure>()
    private var current = ""
    private var startNs = System.nanoTime()
    private var lastEmit = 0L

    fun result(cancelled: Boolean) = OperationResult(done, skipped, failures.toList(), cancelled)

    private suspend fun ensureRunning() {
        if (!currentCoroutineContext().isActive) throw StopRun()
    }

    private fun fail(f: File, error: FileError) { failures.add(OperationFailure(f.absolutePath, error)) }

    private fun emit(force: Boolean) {
        val now = System.nanoTime()
        if (!force && now - lastEmit < 100_000_000L) return
        lastEmit = now
        val seconds = ((now - startNs).coerceAtLeast(1L)) / 1_000_000_000.0
        val bps = (doneBytes / seconds).toLong()
        val remaining = (totalBytes - doneBytes).coerceAtLeast(0L)
        val eta = if (bps > 0 && totalBytes > 0) remaining / bps else null
        onProgress(OperationProgress(type, current, doneFiles, totalFiles, doneBytes, totalBytes, bps, eta))
    }

    // ---------- counting ----------
    private suspend fun countTree(f: File): Pair<Int, Long> {
        ensureRunning()
        if (f.isSymlink()) return 0 to 0L
        if (f.isDirectory) {
            var n = 0
            var b = 0L
            f.listFiles()?.forEach {
                val (cn, cb) = countTree(it)
                n += cn
                b += cb
            }
            return n to b
        }
        return if (f.exists()) 1 to f.length() else 0 to 0L
    }

    private suspend fun countNodes(f: File): Int {
        ensureRunning()
        var n = 1
        if (!f.isSymlink() && f.isDirectory) f.listFiles()?.forEach { n += countNodes(it) }
        return n
    }

    private suspend fun skipTree(src: File) {
        val (n, b) = countTree(src)
        doneFiles += n
        doneBytes += b
        skipped++
        emit(false)
    }

    // ---------- delete ----------
    suspend fun delete(paths: List<String>): OperationResult {
        try {
            for (p in paths) totalFiles += countNodes(File(p))
            startNs = System.nanoTime()
            emit(true)
            for (p in paths) deleteNode(File(p))
            emit(true)
            return result(false)
        } catch (e: StopRun) {
            return result(true)
        }
    }

    private suspend fun deleteNode(f: File): Boolean {
        ensureRunning()
        current = f.name
        if (!f.isSymlink() && f.isDirectory) {
            val children = f.listFiles()
            if (children == null) { fail(f, FileError.ACCESS_DENIED); return false }
            var ok = true
            for (c in children) if (!deleteNode(c)) ok = false
            if (!ok) return false
        }
        val deleted = f.delete()
        if (deleted) { doneFiles++; done++ } else {
            fail(f, if (f.exists()) FileError.ACCESS_DENIED else FileError.NOT_FOUND)
        }
        emit(false)
        return deleted
    }

    // ---------- copy / move ----------
    suspend fun transfer(sources: List<String>, destDir: String, policy: ConflictPolicy): OperationResult {
        try {
            val dest = File(destDir)
            if (!dest.isDirectory) {
                failures.add(OperationFailure(destDir, FileError.NOT_FOUND))
                return result(false)
            }
            for (s in sources) {
                val (n, b) = countTree(File(s))
                totalFiles += n
                totalBytes += b
            }
            if (type == OperationType.COPY) {
                val free = dest.usableSpace
                if (free > 0 && totalBytes > free) {
                    failures.add(OperationFailure(destDir, FileError.NO_SPACE))
                    return result(false)
                }
            }
            startNs = System.nanoTime()
            emit(true)
            for (s in sources) {
                ensureRunning()
                transferNode(File(s), dest, policy)
            }
            emit(true)
            return result(false)
        } catch (e: StopRun) {
            return result(true)
        }
    }

    private fun uniqueTarget(dir: File, name: String): File {
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (true) {
            val candidate = File(dir, "$base ($i)$ext")
            if (!candidate.exists()) return candidate
            i++
        }
    }

    /** Returns true if [src] was fully transferred (and, for move, removed from its source). */
    private suspend fun transferNode(src: File, destDir: File, policy: ConflictPolicy): Boolean {
        ensureRunning()
        current = src.name
        if (src.isSymlink()) { skipped++; return false }
        if (!src.exists()) { fail(src, FileError.NOT_FOUND); return false }

        val srcCanon = canon(src)
        val destCanon = canon(destDir)
        if (src.isDirectory && (destCanon == srcCanon || destCanon.startsWith(srcCanon + File.separator))) {
            fail(src, FileError.INSIDE_ITSELF)
            return false
        }

        var target = File(destDir, src.name)
        if (target.exists()) {
            if (canon(target) == srcCanon) {
                // Source and target are the same file.
                if (type == OperationType.MOVE || policy != ConflictPolicy.KEEP_BOTH) {
                    skipTree(src)
                    return false
                }
                target = uniqueTarget(destDir, src.name)
            } else if (src.isDirectory != target.isDirectory) {
                if (policy == ConflictPolicy.KEEP_BOTH) {
                    target = uniqueTarget(destDir, src.name)
                } else {
                    fail(src, FileError.TYPE_MISMATCH)
                    return false
                }
            } else if (src.isDirectory) {
                if (policy == ConflictPolicy.KEEP_BOTH) target = uniqueTarget(destDir, src.name)
                // SKIP / REPLACE: merge, conflicts inside are resolved per file.
            } else {
                when (policy) {
                    ConflictPolicy.SKIP -> { skipTree(src); return false }
                    ConflictPolicy.REPLACE -> {}
                    ConflictPolicy.KEEP_BOTH -> target = uniqueTarget(destDir, src.name)
                }
            }
        }

        if (src.isDirectory) {
            if (type == OperationType.MOVE && !target.exists()) {
                val (n, b) = countTree(src)
                if (src.renameTo(target)) {
                    doneFiles += n
                    doneBytes += b
                    done++
                    emit(false)
                    return true
                }
            }
            if (!target.exists() && !target.mkdirs()) { fail(target, FileError.ACCESS_DENIED); return false }
            val children = src.listFiles()
            if (children == null) { fail(src, FileError.ACCESS_DENIED); return false }
            var allOk = true
            for (c in children) if (!transferNode(c, target, policy)) allOk = false
            if (type == OperationType.MOVE && allOk && !src.delete()) {
                fail(src, FileError.IO)
                allOk = false
            }
            return allOk
        }

        if (type == OperationType.MOVE && !target.exists() && src.renameTo(target)) {
            doneFiles++
            doneBytes += target.length()
            done++
            emit(false)
            return true
        }
        if (!copyFileSafely(src, target)) return false
        if (type == OperationType.MOVE && !src.delete()) {
            fail(src, FileError.ACCESS_DENIED)
            return false
        }
        return true
    }

    private suspend fun copyFileSafely(src: File, target: File): Boolean {
        val tmp = File(target.parentFile, ".${target.name}.aerotmp")
        var keepTmp = false
        try {
            FileInputStream(src).use { input ->
                FileOutputStream(tmp).use { out ->
                    val buffer = ByteArray(128 * 1024)
                    while (true) {
                        ensureRunning()
                        val n = input.read(buffer)
                        if (n < 0) break
                        out.write(buffer, 0, n)
                        doneBytes += n
                        emit(false)
                    }
                    out.flush()
                }
            }
            if (tmp.length() != src.length()) {
                fail(src, FileError.VERIFY_FAILED)
                return false
            }
            if (!tmp.renameTo(target)) {
                // Some file systems refuse to rename over an existing file.
                if (!(target.delete() && tmp.renameTo(target))) {
                    keepTmp = true // never destroy the only complete copy
                    fail(src, FileError.IO)
                    return false
                }
            }
            target.setLastModified(src.lastModified())
            doneFiles++
            done++
            emit(false)
            return true
        } catch (e: StopRun) {
            throw e
        } catch (e: Exception) {
            fail(src, mapError(e))
            return false
        } finally {
            if (!keepTmp && tmp.exists()) tmp.delete()
        }
    }

    private fun mapError(e: Throwable): FileError {
        val msg = e.message ?: ""
        return when {
            e is SecurityException -> FileError.ACCESS_DENIED
            msg.contains("ENOSPC") || msg.contains("No space left", ignoreCase = true) -> FileError.NO_SPACE
            e is FileNotFoundException &&
                (msg.contains("EACCES") || msg.contains("EROFS") || msg.contains("Permission denied", true)) ->
                FileError.ACCESS_DENIED
            e is FileNotFoundException -> FileError.NOT_FOUND
            else -> FileError.IO
        }
    }
}
