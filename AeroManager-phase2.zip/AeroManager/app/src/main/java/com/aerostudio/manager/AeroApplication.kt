package com.aerostudio.manager

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class AeroApplication : Application()
