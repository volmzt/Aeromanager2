package com.aerostudio.manager.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aerostudio.manager.core.storage.CategoryStat
import com.aerostudio.manager.core.storage.FileCategory
import com.aerostudio.manager.core.storage.FileItem
import com.aerostudio.manager.core.storage.MediaIndexRepository
import com.aerostudio.manager.core.storage.StorageRepository
import com.aerostudio.manager.core.storage.StorageVolume
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class DashboardState(
    val volumes: List<StorageVolume> = emptyList(),
    val selected: Int = 0,
    val categories: Map<FileCategory, CategoryStat> = emptyMap(),
    val recent: List<FileItem> = emptyList(),
    val loading: Boolean = true,
)

@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val storage: StorageRepository,
    private val media: MediaIndexRepository,
) : ViewModel() {
    private val _state = MutableStateFlow(DashboardState())
    val state: StateFlow<DashboardState> = _state.asStateFlow()
    private var job: Job? = null

    fun refresh() {
        job?.cancel()
        job = viewModelScope.launch(Dispatchers.IO) {
            val volumes = storage.volumes()
            _state.update { it.copy(volumes = volumes, selected = it.selected.coerceIn(0, volumes.lastIndex)) }
            val categories = media.categoryStats()
            val recent = media.recentFiles()
            _state.update { it.copy(categories = categories, recent = recent, loading = false) }
        }
    }

    fun select(index: Int) { _state.update { it.copy(selected = index) } }
}
