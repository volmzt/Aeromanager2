package com.aerostudio.manager.core.storage

import java.io.File
import java.nio.file.Files

data class FileItem(
    val path: String,
    val name: String,
    val isDirectory: Boolean,
    val size: Long,
    val modified: Long,
    val isHidden: Boolean,
    val extension: String,
    val category: FileCategory,
    val childCount: Int? = null,
)

fun File.toFileItem(childCount: Int? = null): FileItem {
    val dir = isDirectory
    val ext = if (dir) "" else extension.lowercase()
    return FileItem(
        path = absolutePath,
        name = name,
        isDirectory = dir,
        size = if (dir) 0L else length(),
        modified = lastModified(),
        isHidden = name.startsWith("."),
        extension = ext,
        category = if (dir) FileCategory.FOLDER else FileCategory.fromExtension(ext),
        childCount = if (dir) childCount else null,
    )
}

fun File.isSymlink(): Boolean = try { Files.isSymbolicLink(toPath()) } catch (e: Exception) { false }
