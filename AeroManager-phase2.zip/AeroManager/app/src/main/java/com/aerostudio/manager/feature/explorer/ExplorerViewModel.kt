package com.aerostudio.manager.feature.explorer

import androidx.annotation.StringRes
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.aerostudio.manager.R
import com.aerostudio.manager.core.settings.SettingsRepository
import com.aerostudio.manager.core.settings.SortField
import com.aerostudio.manager.core.settings.ViewMode
import com.aerostudio.manager.core.storage.ConflictPolicy
import com.aerostudio.manager.core.storage.FileAccessProvider
import com.aerostudio.manager.core.storage.FileError
import com.aerostudio.manager.core.storage.FileException
import com.aerostudio.manager.core.storage.FileItem
import com.aerostudio.manager.core.storage.FileOperationEngine
import com.aerostudio.manager.core.storage.OperationProgress
import com.aerostudio.manager.core.storage.OperationResult
import com.aerostudio.manager.core.storage.OperationType
import com.aerostudio.manager.core.storage.StorageRepository
import com.aerostudio.manager.core.storage.sortItems
import dagger.hilt.android.lifecycle.HiltViewModel
import java.io.File
import javax.inject.Inject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

@HiltViewModel
class ExplorerViewModel @Inject constructor(
    private val provider: FileAccessProvider,
    private val engine: FileOperationEngine,
    private val storage: StorageRepository,
    private val settingsRepo: SettingsRepository,
) : ViewModel() {

    private val _state = MutableStateFlow(
        ExplorerState(
            root = storage.primaryRoot(),
            path = storage.primaryRoot(),
            volumes = storage.volumes(),
        ),
    )
    val state: StateFlow<ExplorerState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<UiMessage>(extraBufferCapacity = 8)
    val events: SharedFlow<UiMessage> = _events.asSharedFlow()

    @Volatile private var raw: List<FileItem> = emptyList()
    private var listJob: Job? = null
    private var opJob: Job? = null
    private var started = false
    private val back = ArrayDeque<String>()
    private val forward = ArrayDeque<String>()

    init {
        viewModelScope.launch {
            settingsRepo.settings.collect { s ->
                val hiddenChanged = _state.value.showHidden != s.showHidden
                _state.update {
                    it.copy(
                        viewMode = s.viewMode,
                        sortField = s.sortField,
                        sortAscending = s.sortAscending,
                        showHidden = s.showHidden,
                    )
                }
                if (started) {
                    if (hiddenChanged) load(_state.value.path) else applySort()
                }
            }
        }
    }

    // ---------- lifecycle ----------
    fun start() {
        if (started) return
        started = true
        _state.update { it.copy(volumes = storage.volumes()) }
        load(_state.value.path)
    }

    fun refresh() {
        _state.update { it.copy(volumes = storage.volumes()) }
        load(_state.value.path)
    }

    fun notify(@StringRes res: Int) { _events.tryEmit(UiMessage(res)) }

    // ---------- navigation ----------
    private fun rootFor(path: String): String =
        _state.value.volumes.map { it.path }
            .filter { path == it || path.startsWith("$it/") }
            .maxByOrNull { it.length } ?: "/"

    fun open(item: FileItem) { if (item.isDirectory) navigateTo(item.path) }

    fun navigateTo(path: String) {
        val current = _state.value.path
        if (path == current) return
        back.addLast(current)
        forward.clear()
        go(path)
    }

    fun goBack() {
        val current = _state.value.path
        if (back.isNotEmpty()) {
            forward.addLast(current)
            go(back.removeLast())
        } else if (_state.value.canGoUp) {
            File(current).parent?.let { navigateTo(it) }
        }
    }

    fun goForward() {
        if (forward.isEmpty()) return
        back.addLast(_state.value.path)
        go(forward.removeLast())
    }

    private fun go(path: String) {
        _state.update {
            it.copy(
                root = rootFor(path),
                canGoBack = back.isNotEmpty(),
                canGoForward = forward.isNotEmpty(),
            )
        }
        load(path)
    }

    private fun load(path: String) {
        listJob?.cancel()
        _state.update { it.copy(path = path, loading = true, error = null, selection = emptySet()) }
        val showHidden = _state.value.showHidden
        listJob = viewModelScope.launch(Dispatchers.IO) {
            try {
                val items = provider.list(path, showHidden)
                raw = items
                _state.update {
                    it.copy(items = sortItems(items, it.sortField, it.sortAscending), loading = false)
                }
            } catch (e: FileException) {
                failLoad(e.error)
            } catch (e: SecurityException) {
                failLoad(FileError.ACCESS_DENIED)
            }
        }
    }

    private fun failLoad(error: FileError) {
        raw = emptyList()
        _state.update { it.copy(items = emptyList(), loading = false, error = error) }
    }

    private fun applySort() {
        _state.update { it.copy(items = sortItems(raw, it.sortField, it.sortAscending)) }
    }

    // ---------- view settings ----------
    fun setViewMode(mode: ViewMode) { viewModelScope.launch { settingsRepo.setViewMode(mode) } }
    fun setSort(field: SortField, ascending: Boolean) { viewModelScope.launch { settingsRepo.setSort(field, ascending) } }
    fun setShowHidden(show: Boolean) { viewModelScope.launch { settingsRepo.setShowHidden(show) } }

    // ---------- selection ----------
    fun toggleSelection(path: String) = _state.update {
        it.copy(selection = if (path in it.selection) it.selection - path else it.selection + path)
    }

    fun selectAll() = _state.update { it.copy(selection = it.items.map { i -> i.path }.toSet()) }

    fun invertSelection() = _state.update {
        it.copy(selection = it.items.map { i -> i.path }.toSet() - it.selection)
    }

    fun clearSelection() = _state.update { it.copy(selection = emptySet()) }

    // ---------- clipboard ----------
    fun copySelection(move: Boolean) {
        _state.update { s ->
            if (s.selection.isEmpty()) s
            else s.copy(
                clipboard = Clipboard(s.items.filter { it.path in s.selection }.map { it.path }, move),
                selection = emptySet(),
            )
        }
    }

    fun cancelClipboard() = _state.update { it.copy(clipboard = null) }

    fun paste() {
        val clip = _state.value.clipboard ?: return
        val dest = _state.value.path
        viewModelScope.launch(Dispatchers.IO) {
            val conflicts = engine.findConflicts(clip.paths, dest)
            if (conflicts.isEmpty()) {
                runTransfer(clip, dest, ConflictPolicy.KEEP_BOTH)
            } else {
                _state.update { it.copy(conflict = ConflictRequest(clip, dest, conflicts)) }
            }
        }
    }

    /** [policy] == null means the user cancelled the paste. */
    fun resolveConflict(policy: ConflictPolicy?) {
        val c = _state.value.conflict ?: return
        _state.update { it.copy(conflict = null) }
        if (policy != null) runTransfer(c.clipboard, c.destination, policy)
    }

    private fun runTransfer(clip: Clipboard, dest: String, policy: ConflictPolicy) {
        val type = if (clip.move) OperationType.MOVE else OperationType.COPY
        startOperation(type) { onProgress -> engine.transfer(type, clip.paths, dest, policy, onProgress) }
    }

    // ---------- delete ----------
    fun requestDelete() {
        val s = _state.value
        if (s.selection.isEmpty()) return
        _state.update { it.copy(pendingDelete = it.items.filter { i -> i.path in it.selection }.map { i -> i.path }) }
    }

    fun cancelDelete() = _state.update { it.copy(pendingDelete = null) }

    fun confirmDelete() {
        val paths = _state.value.pendingDelete ?: return
        _state.update { it.copy(pendingDelete = null, selection = emptySet()) }
        startOperation(OperationType.DELETE) { onProgress -> engine.delete(paths, onProgress) }
    }

    // ---------- running operations ----------
    private fun startOperation(
        type: OperationType,
        block: suspend ((OperationProgress) -> Unit) -> OperationResult,
    ) {
        _state.update { it.copy(operation = OperationProgress(type)) }
        opJob = viewModelScope.launch(Dispatchers.IO) {
            val result = block { p -> _state.update { it.copy(operation = p) } }
            _state.update {
                it.copy(
                    operation = null,
                    clipboard = if (type == OperationType.MOVE) null else it.clipboard,
                    report = if (result.hasIssues) result else null,
                )
            }
            load(_state.value.path)
            if (!result.hasIssues) {
                _events.tryEmit(UiMessage(if (result.cancelled) R.string.op_cancelled else R.string.op_done))
            }
        }
    }

    fun cancelOperation() { opJob?.cancel() }

    fun dismissReport() = _state.update { it.copy(report = null) }

    // ---------- create / rename ----------
    fun create(name: String, folder: Boolean) {
        val parent = _state.value.path
        val clean = name.trim()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (folder) provider.createFolder(parent, clean) else provider.createFile(parent, clean)
                _events.tryEmit(UiMessage(R.string.msg_created, clean))
                load(_state.value.path)
            } catch (e: FileException) {
                _events.tryEmit(UiMessage(e.error.messageRes()))
            }
        }
    }

    fun rename(item: FileItem, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                provider.rename(item.path, newName.trim())
                _events.tryEmit(UiMessage(R.string.msg_renamed))
                load(_state.value.path)
            } catch (e: FileException) {
                _events.tryEmit(UiMessage(e.error.messageRes()))
            }
        }
    }

    /** Names items "base 1.ext", "base 2.ext", ... in the order they appear in the list. */
    fun batchRename(items: List<FileItem>, base: String) {
        val prefix = base.trim()
        viewModelScope.launch(Dispatchers.IO) {
            val failures = mutableListOf<com.aerostudio.manager.core.storage.OperationFailure>()
            var renamed = 0
            items.forEachIndexed { index, item ->
                val dot = item.name.lastIndexOf('.')
                val ext = if (!item.isDirectory && dot > 0) item.name.substring(dot) else ""
                try {
                    provider.rename(item.path, "$prefix ${index + 1}$ext")
                    renamed++
                } catch (e: FileException) {
                    failures.add(com.aerostudio.manager.core.storage.OperationFailure(item.path, e.error))
                }
            }
            if (failures.isEmpty()) {
                _events.tryEmit(UiMessage(R.string.msg_renamed))
            } else {
                _state.update { it.copy(report = OperationResult(renamed, 0, failures, false)) }
            }
            load(_state.value.path)
        }
    }
}
