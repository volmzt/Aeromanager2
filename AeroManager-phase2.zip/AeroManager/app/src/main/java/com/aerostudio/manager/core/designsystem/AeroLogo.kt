package com.aerostudio.manager.core.designsystem

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Geometric "A": a chevron with a crossbar, drawn on a 64x64 grid. */
@Composable
fun AeroLogo(
    modifier: Modifier = Modifier,
    size: Dp = 32.dp,
    color: Color = MaterialTheme.colorScheme.primary,
) {
    Canvas(modifier.size(size)) {
        val s = this.size.minDimension / 64f
        val path = Path().apply {
            moveTo(32f * s, 4f * s); lineTo(58f * s, 60f * s); lineTo(46f * s, 60f * s)
            lineTo(32f * s, 30f * s); lineTo(18f * s, 60f * s); lineTo(6f * s, 60f * s); close()
            moveTo(22f * s, 46f * s); lineTo(42f * s, 46f * s); lineTo(42f * s, 54f * s)
            lineTo(22f * s, 54f * s); close()
        }
        drawPath(path, color)
    }
}
