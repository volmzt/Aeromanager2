package com.aerostudio.manager.core.storage

import com.aerostudio.manager.core.settings.SortField

/** Folders always come first; [ascending] applies inside each group. */
fun sortItems(items: List<FileItem>, field: SortField, ascending: Boolean): List<FileItem> {
    val byName = compareBy<FileItem, String>(String.CASE_INSENSITIVE_ORDER) { it.name }
    val base: Comparator<FileItem> = when (field) {
        SortField.NAME -> byName
        SortField.SIZE -> compareBy<FileItem> { it.size }.then(byName)
        SortField.DATE -> compareBy<FileItem> { it.modified }.then(byName)
        SortField.TYPE -> compareBy<FileItem> { it.extension }.then(byName)
    }
    val ordered = if (ascending) base else base.reversed()
    return items.sortedWith(compareByDescending<FileItem> { it.isDirectory }.then(ordered))
}
