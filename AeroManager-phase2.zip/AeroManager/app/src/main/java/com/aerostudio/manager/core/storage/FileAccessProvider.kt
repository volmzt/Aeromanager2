package com.aerostudio.manager.core.storage

/**
 * Abstraction over how files are accessed. Phase 2 has only the standard
 * (java.io) implementation; Shizuku and Root providers arrive in Phase 6.
 * All calls are blocking: call them off the main thread.
 */
interface FileAccessProvider {
    val id: String
    fun list(path: String, showHidden: Boolean): List<FileItem>
    fun createFolder(parent: String, name: String): FileItem
    fun createFile(parent: String, name: String): FileItem
    fun rename(path: String, newName: String): FileItem
}
