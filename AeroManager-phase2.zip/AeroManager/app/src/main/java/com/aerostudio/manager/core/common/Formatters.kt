package com.aerostudio.manager.core.common

import android.content.Context
import android.text.format.Formatter
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.aerostudio.manager.R
import java.text.DateFormat
import java.util.Date

fun formatSize(context: Context, bytes: Long): String = Formatter.formatFileSize(context, bytes)

fun formatDate(millis: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(millis))

fun formatDuration(seconds: Long): String {
    val h = seconds / 3600
    val m = (seconds % 3600) / 60
    val s = seconds % 60
    return if (h > 0) String.format("%d:%02d:%02d", h, m, s) else String.format("%d:%02d", m, s)
}

fun Context.itemsText(count: Int): String =
    resources.getQuantityString(R.plurals.items_count, count, count)

@Composable
fun itemsText(count: Int): String = LocalContext.current.itemsText(count)
