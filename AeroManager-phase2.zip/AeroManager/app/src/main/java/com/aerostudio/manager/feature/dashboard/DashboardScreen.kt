package com.aerostudio.manager.feature.dashboard

import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.aerostudio.manager.R
import com.aerostudio.manager.core.common.formatDate
import com.aerostudio.manager.core.common.formatSize
import com.aerostudio.manager.core.common.itemsText
import com.aerostudio.manager.core.designsystem.AeroLogo
import com.aerostudio.manager.core.designsystem.categoryColor
import com.aerostudio.manager.core.designsystem.categoryIcon
import com.aerostudio.manager.core.designsystem.categoryLabel
import com.aerostudio.manager.core.permissions.PermissionCard
import com.aerostudio.manager.core.permissions.rememberStorageAccess
import com.aerostudio.manager.core.storage.CategoryStat
import com.aerostudio.manager.core.storage.FileCategory
import com.aerostudio.manager.core.storage.FileOpener
import com.aerostudio.manager.feature.explorer.FileIcon
import androidx.compose.material3.Icon
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color

@Composable
fun DashboardScreen(onOpenFiles: () -> Unit, vm: DashboardViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val state by vm.state.collectAsStateWithLifecycle()
    val access = rememberStorageAccess()
    LaunchedEffect(access.granted) { vm.refresh() }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            AeroLogo(size = 32.dp)
            Text(
                stringResource(R.string.app_name),
                style = MaterialTheme.typography.headlineSmall,
                modifier = Modifier.padding(start = 12.dp),
            )
        }

        if (!access.granted) PermissionCard(onGrant = access.request)

        // ----- storage overview -----
        val volume = state.volumes.getOrNull(state.selected)
        if (volume != null) {
            Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.dash_storage), style = MaterialTheme.typography.titleMedium)
                    if (state.volumes.size > 1) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            state.volumes.forEachIndexed { i, v ->
                                FilterChip(
                                    selected = i == state.selected,
                                    onClick = { vm.select(i) },
                                    label = {
                                        Text(if (v.isPrimary) stringResource(R.string.dash_internal) else v.name)
                                    },
                                )
                            }
                        }
                    }
                    Text(
                        if (volume.isPrimary) stringResource(R.string.dash_internal)
                        else stringResource(R.string.dash_removable) + " · " + volume.name,
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    LinearProgressIndicator(
                        progress = { volume.usedFraction },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        stringResource(
                            R.string.dash_used,
                            formatSize(context, volume.used),
                            formatSize(context, volume.total),
                        ),
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        stringResource(R.string.dash_free, formatSize(context, volume.free)),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }

        // ----- categories -----
        Text(stringResource(R.string.dash_categories), style = MaterialTheme.typography.titleMedium)
        val cats = FileCategory.entries.filter { it != FileCategory.FOLDER }
        cats.chunked(2).forEach { pair ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                pair.forEach { cat ->
                    CategoryCard(
                        cat,
                        state.categories[cat],
                        onClick = onOpenFiles,
                        modifier = Modifier.weight(1f),
                    )
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        Text(
            stringResource(R.string.dash_approx),
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        // ----- recent files -----
        Text(stringResource(R.string.dash_recent), style = MaterialTheme.typography.titleMedium)
        if (state.recent.isEmpty()) {
            Text(
                stringResource(R.string.dash_no_recent),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        } else {
            state.recent.forEach { item ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            if (!FileOpener.open(context, item.path)) {
                                Toast.makeText(context, R.string.msg_no_app, Toast.LENGTH_SHORT).show()
                            }
                        }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    FileIcon(item.category, selected = false)
                    Column(Modifier.padding(start = 12.dp)) {
                        Text(
                            item.name,
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            formatSize(context, item.size) + " · " + formatDate(item.modified),
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryCard(
    cat: FileCategory,
    stat: CategoryStat?,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val color = categoryColor(cat)
    Surface(
        modifier = modifier.clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(categoryIcon(cat), null, tint = color, modifier = Modifier.size(28.dp))
            Column(Modifier.padding(start = 12.dp)) {
                Text(stringResource(categoryLabel(cat)), style = MaterialTheme.typography.titleSmall)
                Text(
                    if (stat == null) "…" else itemsText(stat.count) + " · " + formatSize(context, stat.bytes),
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}
