package com.aerostudio.manager

import androidx.compose.ui.graphics.Color
import com.aerostudio.manager.core.designsystem.readableOn
import com.aerostudio.manager.core.settings.AppSettings
import com.aerostudio.manager.core.settings.ThemeMode
import org.junit.Assert.assertEquals
import org.junit.Test

class CoreTest {
    @Test fun defaultsAreSystemThemeAndBlueAccent() {
        val s = AppSettings()
        assertEquals(ThemeMode.SYSTEM, s.themeMode)
        assertEquals(AppSettings.DEFAULT_ACCENT, s.accent)
    }

    @Test fun readableTextColor() {
        assertEquals(Color.Black, readableOn(Color.White))
        assertEquals(Color.White, readableOn(Color.Black))
    }
}
