package com.aerostudio.manager

import com.aerostudio.manager.core.settings.SortField
import com.aerostudio.manager.core.storage.FileCategory
import com.aerostudio.manager.core.storage.FileItem
import com.aerostudio.manager.core.storage.sortItems
import com.aerostudio.manager.core.storage.validateName
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class SortingTest {
    private fun item(name: String, dir: Boolean = false, size: Long = 0, ext: String = "") = FileItem(
        path = "/$name", name = name, isDirectory = dir, size = size, modified = 0, isHidden = false,
        extension = ext, category = if (dir) FileCategory.FOLDER else FileCategory.OTHER,
    )

    @Test fun foldersFirstThenNameIgnoringCase() {
        val sorted = sortItems(listOf(item("b.txt"), item("Z", dir = true), item("a.txt")), SortField.NAME, true)
        assertEquals(listOf("Z", "a.txt", "b.txt"), sorted.map { it.name })
    }

    @Test fun sizeDescending() {
        val sorted = sortItems(listOf(item("a", size = 1), item("b", size = 5)), SortField.SIZE, false)
        assertEquals(listOf("b", "a"), sorted.map { it.name })
    }

    @Test fun nameValidation() {
        assertNull(validateName("ok.txt"))
        assertNotNull(validateName(""))
        assertNotNull(validateName("a/b"))
        assertNotNull(validateName(".."))
    }
}
