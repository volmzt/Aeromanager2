package com.aerostudio.manager

import com.aerostudio.manager.core.storage.ConflictPolicy
import com.aerostudio.manager.core.storage.FileError
import com.aerostudio.manager.core.storage.FileOperationEngine
import com.aerostudio.manager.core.storage.OperationType
import java.io.File
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class FileOperationEngineTest {
    @get:Rule val tmp = TemporaryFolder()
    private val engine = FileOperationEngine()

    private fun write(dir: File, name: String, text: String): File =
        File(dir, name).apply { parentFile?.mkdirs(); writeText(text) }

    @Test fun copyKeepsSourceAndContent() = runBlocking<Unit> {
        val src = tmp.newFolder("src"); val dst = tmp.newFolder("dst")
        val f = write(src, "a.txt", "hello")
        val r = engine.transfer(OperationType.COPY, listOf(f.path), dst.path, ConflictPolicy.KEEP_BOTH) {}
        assertEquals(1, r.done)
        assertTrue(f.exists())
        assertEquals("hello", File(dst, "a.txt").readText())
        assertTrue(dst.listFiles()!!.none { it.name.endsWith(".aerotmp") })
    }

    @Test fun moveRemovesSource() = runBlocking<Unit> {
        val src = tmp.newFolder("src"); val dst = tmp.newFolder("dst")
        val f = write(src, "a.txt", "x")
        val r = engine.transfer(OperationType.MOVE, listOf(f.path), dst.path, ConflictPolicy.KEEP_BOTH) {}
        assertFalse(r.hasIssues)
        assertFalse(f.exists())
        assertTrue(File(dst, "a.txt").exists())
    }

    @Test fun conflictReplace() = runBlocking<Unit> {
        val src = tmp.newFolder("src"); val dst = tmp.newFolder("dst")
        val f = write(src, "a.txt", "new"); write(dst, "a.txt", "old")
        assertEquals(listOf("a.txt"), engine.findConflicts(listOf(f.path), dst.path))
        engine.transfer(OperationType.COPY, listOf(f.path), dst.path, ConflictPolicy.REPLACE) {}
        assertEquals("new", File(dst, "a.txt").readText())
    }

    @Test fun conflictKeepBoth() = runBlocking<Unit> {
        val src = tmp.newFolder("src"); val dst = tmp.newFolder("dst")
        val f = write(src, "a.txt", "new"); write(dst, "a.txt", "old")
        engine.transfer(OperationType.COPY, listOf(f.path), dst.path, ConflictPolicy.KEEP_BOTH) {}
        assertEquals("old", File(dst, "a.txt").readText())
        assertEquals("new", File(dst, "a (1).txt").readText())
    }

    @Test fun conflictSkip() = runBlocking<Unit> {
        val src = tmp.newFolder("src"); val dst = tmp.newFolder("dst")
        val f = write(src, "a.txt", "new"); write(dst, "a.txt", "old")
        val r = engine.transfer(OperationType.COPY, listOf(f.path), dst.path, ConflictPolicy.SKIP) {}
        assertEquals(1, r.skipped)
        assertEquals("old", File(dst, "a.txt").readText())
    }

    @Test fun duplicateInSameFolder() = runBlocking<Unit> {
        val src = tmp.newFolder("src")
        val f = write(src, "a.txt", "x")
        assertTrue(engine.findConflicts(listOf(f.path), src.path).isEmpty())
        engine.transfer(OperationType.COPY, listOf(f.path), src.path, ConflictPolicy.KEEP_BOTH) {}
        assertTrue(File(src, "a (1).txt").exists())
    }

    @Test fun folderCannotGoIntoItself() = runBlocking<Unit> {
        val src = tmp.newFolder("src")
        val sub = File(src, "sub").apply { mkdirs() }
        val r = engine.transfer(OperationType.COPY, listOf(src.path), sub.path, ConflictPolicy.KEEP_BOTH) {}
        assertEquals(FileError.INSIDE_ITSELF, r.failures.single().error)
    }

    @Test fun copyFolderRecursively() = runBlocking<Unit> {
        val src = tmp.newFolder("src"); val dst = tmp.newFolder("dst")
        write(src, "dir/one.txt", "1"); write(src, "dir/deep/two.txt", "22")
        engine.transfer(OperationType.COPY, listOf(File(src, "dir").path), dst.path, ConflictPolicy.KEEP_BOTH) {}
        assertEquals("22", File(dst, "dir/deep/two.txt").readText())
    }

    @Test fun deleteRecursively() = runBlocking<Unit> {
        val src = tmp.newFolder("src")
        write(src, "dir/one.txt", "1"); write(src, "dir/deep/two.txt", "2")
        val r = engine.delete(listOf(File(src, "dir").path)) {}
        assertFalse(r.hasIssues)
        assertFalse(File(src, "dir").exists())
    }
}
