<p align="center"><img src="assets/logo.svg" width="128" alt="Aero Manager logo"></p>

# Aero Manager

Professional Android file manager with its own visual language, **Aero Design**.
Kotlin · Jetpack Compose · Material 3 · Hilt · DataStore · Clean Architecture + MVVM.

## Status

**Phase 2 (Core file manager) is implemented.**

- Dashboard: real storage usage, category statistics (from the system media index, approximate), recent files.
- Files: browsing, breadcrumbs, back/forward/up, list / grid / compact / detailed views, sorting, hidden files.
- Operations: copy, cut/paste, delete (permanent for now, Trash comes in Phase 3), rename, batch rename, create folder/file,
  multi-select, share, open, copy path, file information.
- Safe copy: temp file, size verification, atomic rename; conflict dialog (skip / replace / keep both);
  progress, speed, ETA, cancel and an error report.
- Storage permission is requested only when needed (All files access on Android 11+).

Not yet implemented: search, favorites, trash, analyzer, archives, viewers, Shizuku/Root, USB/SD via SAF, automation.

## Requirements

Android 8.0 (API 26) or newer.

## Download the APK

- **Latest build:** GitHub → Actions → a successful *Android Build* run → Artifacts → `AeroManager-v…-build…`.
- **Permanent releases:** GitHub → Releases (created when you push a tag like `v1.0.0`).

Enable "Install unknown apps" for your browser/file manager to install the APK.

## Build locally

JDK 17 and Android SDK (API 35) are required. The repo has no Gradle wrapper; use Gradle 8.11.1:

```
gradle :app:assembleDebug
```

(Run `gradle wrapper --gradle-version 8.11.1` once to generate the wrapper if you want one.)

## GitHub Actions

`.github/workflows/android-build.yml` runs on push to `main`/`master`, pull requests, manual dispatch and `v*` tags:
compile → Android Lint → unit tests → debug APK → signed release APK (only if secrets exist) → GitHub Release on tags.

Debug APK needs no secrets. For signed releases add repository secrets:
`KEYSTORE_BASE64` (`base64 -w0 release.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
Without them the release signing step is skipped with a warning, and a tag build fails instead of publishing an unsigned release.

Version is set in `gradle.properties` (`APP_VERSION_NAME`, `APP_VERSION_CODE`).

## Root and Shizuku

Planned for Phase 6. Privileged actions will always be user-initiated and never bypass the Android security model.

## License

To be chosen by the project owner.
